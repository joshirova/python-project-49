#!/usr/bin/env python3

# brain_games.py

def welcome_user():
    print("Welcome to the Brain Games!")

def main():
    welcome_user()

if __name__ == "__main__":
    main()

