### Hexlet tests and linter status:

[![Maintainability](https://api.codeclimate.com/v1/badges/b52056a9b73c46aab3b4/maintainability)](https://codeclimate.com/github/joshirova/python-project-49/maintainability)

[![Actions Status](https://github.com/joshirova/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/joshirova/python-project-49/actions)
## Demo

[![asciinema](https://asciinema.org/a/tIq2ox1wu9sND1k1xKG3Y9u9n.svg)](https://asciinema.org/a/tIq2ox1wu9sND1k1xKG3Y9u9n)

### Демонстрация игры "Калькулятор"

[![asciicast](https://asciinema.org/a/jhFmipxgLAC1fZdSFT2kkNl8b.svg)](https://asciinema.org/a/jhFmipxgLAC1fZdSFT2kkNl8b)

### Демонстрация игры "НОД"

[![asciicast](https://asciinema.org/a/nRoQohm2EDB2dxa5SBKyTlFXJ.svg)](https://asciinema.org/a/nRoQohm2EDB2dxa5SBKyTlFXJ)

### Демонстрация игры "Арифметическая прогрессия"

[![asciicast](https://asciinema.org/a/EfSg79bVd1QNM9rfLMOO46E6e.svg)](https://asciinema.org/a/EfSg79bVd1QNM9rfLMOO46E6e)

